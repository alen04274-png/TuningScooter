# Scooter Tuning App (Android)

Kotlin/Jetpack-Compose-App zur Steuerung von Xiaomi/Ninebot-E-Scootern via Bluetooth LE.

## Funktionen
- **Dashboard**: Live-Geschwindigkeit, Akku, Gesamtstrecke, aktuelles Limit
- **Fahrmodus**: Eco / Drive / Sport umschalten
- **Tuning**: Geschwindigkeitslimit per Slider anpassen

## So bekommst du eine installierbare APK (ganz ohne PC/Mac)

1. Repo-Inhalt **komplett** (mit allen Unterordnern!) zu GitHub hochladen –
   die Ordnerstruktur muss erhalten bleiben (`.github/`, `app/`, etc.)
2. Gehe in deinem GitHub-Repo zum Tab **"Actions"**
3. Dort sollte automatisch ein Workflow-Lauf **"Build APK"** starten (dauert
   ca. 3–5 Minuten). Falls nicht: auf **"Build APK"** links klicken → **"Run workflow"**
4. Wenn der Lauf grün/fertig ist: draufklicken → ganz unten bei
   **"Artifacts"** liegt **scooter-tuning-apk** zum Download
5. Die heruntergeladene ZIP enthält die `app-debug.apk` – diese aufs Handy
   übertragen (z. B. per Google Drive) und installieren
   (Android fragt nach Erlaubnis für "Installation aus unbekannten Quellen" –
   das ist normal bei selbstgebauten Apps)

**Kein Apple-Account, keine Kosten, kein Codemagic nötig** – GitHub Actions ist für
private Repos mit einem kostenlosen Kontingent von 2000 Minuten/Monat dabei,
das reicht hier locker.

## Wichtig: BLE-Protokoll-Details verifizieren

Die Datei `bluetooth/NinebotProtocol.kt` enthält das öffentlich dokumentierte
Ninebot/Xiaomi-BLE-Grundschema. Die Standard-Befehle (Akku/Speed/Mileage/Firmware
auslesen) funktionieren bei den meisten Modellen zuverlässig.

Der Befehl `WRITE_SPEED_LIMIT` ist ein **Platzhalter**. Das exakte Register und die
Byte-Kodierung unterscheiden sich je nach Modell/Firmware-Version. Bevor du live
sendest:
1. Firmware-Version über die App auslesen (bereits implementiert)
2. In aktuellen Community-Repos (Suche "Ninebot BLE protocol" auf GitHub) das
   passende Kommando nachschlagen
3. Payload in `NinebotProtocol.kt` entsprechend anpassen

Auch die GATT-UUIDs in `ScooterBLEConstants` ggf. mit einer BLE-Scanner-App
(z. B. "nRF Connect", kostenlos im Play Store) an deinem eigenen Scooter verifizieren.

## Rechtlicher Hinweis
Ein entdrosselter E-Scooter darf in Deutschland ausschließlich auf Privatgelände
ohne öffentlichen Verkehr gefahren werden. Sobald das Fahrzeug auch nur gelegentlich
auf öffentlichen Straßen/Wegen genutzt wird, erlischt die Betriebserlaubnis nach
StVZO und der Versicherungsschutz.
