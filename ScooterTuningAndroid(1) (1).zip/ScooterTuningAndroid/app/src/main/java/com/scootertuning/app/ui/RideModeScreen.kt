package com.scootertuning.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scootertuning.app.bluetooth.BleManager
import com.scootertuning.app.model.RideMode

private data class ModeInfo(val icon: ImageVector, val color: Color, val description: String)

private val modeInfoMap = mapOf(
    RideMode.ECO to ModeInfo(Icons.Default.Eco, Color(0xFF4CAF50), "Reduzierte Leistung, längere Reichweite"),
    RideMode.DRIVE to ModeInfo(Icons.Default.DirectionsCar, Color(0xFF2196F3), "Ausgewogenes Fahrverhalten"),
    RideMode.SPORT to ModeInfo(Icons.Default.LocalFireDepartment, Color(0xFFF44336), "Volle Leistung, maximale Beschleunigung")
)

@Composable
fun RideModeScreen(bleManager: BleManager) {
    val state by bleManager.state

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        items(RideMode.entries.toList()) { mode ->
            val info = modeInfoMap.getValue(mode)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                onClick = { bleManager.setRideMode(mode) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(info.icon, contentDescription = null, tint = info.color, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mode.label, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(info.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (state.rideMode == mode) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
