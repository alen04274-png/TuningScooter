package com.scootertuning.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.scootertuning.app.bluetooth.BleManager
import com.scootertuning.app.ui.RootScreen

class MainActivity : ComponentActivity() {

    private lateinit var bleManager: BleManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bleManager = BleManager(applicationContext)

        setContent {
            var hasPermissions by remember { mutableStateOf(false) }

            val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            } else {
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            }

            val launcher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { results ->
                hasPermissions = results.values.all { it }
            }

            LaunchedEffect(Unit) {
                launcher.launch(permissions)
            }

            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (hasPermissions) {
                        RootScreen(bleManager = bleManager)
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Bluetooth-Berechtigung wird benötigt")
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { launcher.launch(permissions) }) {
                                    Text("Erneut anfragen")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
