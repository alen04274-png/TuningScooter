package com.scootertuning.app.model

enum class RideMode(val code: Int, val label: String) {
    ECO(0, "Eco"),
    DRIVE(1, "Drive"),
    SPORT(2, "Sport");

    companion object {
        fun fromCode(code: Int): RideMode = entries.firstOrNull { it.code == code } ?: DRIVE
    }
}

data class ScooterState(
    val isConnected: Boolean = false,
    val batteryPercent: Int = 0,
    val batteryVoltage: Double = 0.0,
    val currentSpeedKmh: Double = 0.0,
    val totalDistanceKm: Double = 0.0,
    val tripDistanceKm: Double = 0.0,
    val rideMode: RideMode = RideMode.DRIVE,
    val speedLimitKmh: Double = 20.0,
    val isSpeedUnlocked: Boolean = false,
    val firmwareVersion: String = "–",
    val errorCode: Int = 0
)
