package com.scootertuning.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.scootertuning.app.model.RideMode
import com.scootertuning.app.model.ScooterState
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class BleManager(private val context: Context) {

    var state = mutableStateOf(ScooterState())
        private set

    val discoveredDevices = mutableStateListOf<BluetoothDevice>()
    var isScanning = mutableStateOf(false)
        private set
    var lastError = mutableStateOf<String?>(null)
        private set

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? get() = bluetoothManager.adapter

    private var gatt: BluetoothGatt? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null
    private var pollJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val seenDeviceIds = ConcurrentHashMap<String, Boolean>()

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = device.name ?: return
            val lower = name.lowercase()
            if (lower.contains("mi") || lower.contains("ninebot") || lower.contains("scooter")) {
                if (seenDeviceIds.putIfAbsent(device.address, true) == null) {
                    discoveredDevices.add(device)
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            lastError.value = "Scan fehlgeschlagen (Code $errorCode)"
            isScanning.value = false
        }
    }

    fun startScan() {
        val bleAdapter = adapter
        if (bleAdapter == null || !bleAdapter.isEnabled) {
            lastError.value = "Bluetooth ist nicht aktiv."
            return
        }
        discoveredDevices.clear()
        seenDeviceIds.clear()
        isScanning.value = true
        bleAdapter.bluetoothLeScanner?.startScan(scanCallback)

        scope.launch {
            delay(8000)
            stopScan()
        }
    }

    fun stopScan() {
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
        isScanning.value = false
    }

    fun connect(device: BluetoothDevice) {
        stopScan()
        gatt = device.connectGatt(context, false, gattCallback)
    }

    fun disconnect() {
        pollJob?.cancel()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        state.value = state.value.copy(isConnected = false)
    }

    private fun send(packet: ByteArray) {
        val g = gatt ?: return
        val characteristic = writeCharacteristic ?: return
        characteristic.value = packet
        g.writeCharacteristic(characteristic)
    }

    fun requestBattery() = send(NinebotProtocol.buildPacket(NinebotProtocol.Command.READ_BATTERY))
    fun requestSpeed() = send(NinebotProtocol.buildPacket(NinebotProtocol.Command.READ_SPEED))
    fun requestMileage() = send(NinebotProtocol.buildPacket(NinebotProtocol.Command.READ_MILEAGE))
    fun requestFirmwareVersion() = send(NinebotProtocol.buildPacket(NinebotProtocol.Command.READ_FIRMWARE))

    fun setRideMode(mode: RideMode) {
        send(NinebotProtocol.buildPacket(NinebotProtocol.Command.WRITE_MODE, byteArrayOf(mode.code.toByte())))
        state.value = state.value.copy(rideMode = mode)
    }

    /** Setzt ein Geschwindigkeitslimit (km/h) über das ESC-Register. Nur auf Privatgelände! */
    fun setSpeedLimit(kmh: Double) {
        val clamped = kmh.coerceIn(0.0, 100.0)
        val raw = (clamped * 100).toInt()
        val payload = byteArrayOf((raw and 0xFF).toByte(), ((raw shr 8) and 0xFF).toByte())
        send(NinebotProtocol.buildPacket(NinebotProtocol.Command.WRITE_SPEED_LIMIT, payload))
        state.value = state.value.copy(speedLimitKmh = clamped, isSpeedUnlocked = clamped > 20.0)
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                requestSpeed()
                requestBattery()
                delay(1000)
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    state.value = state.value.copy(isConnected = true)
                    g.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    state.value = state.value.copy(isConnected = false)
                    pollJob?.cancel()
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val service = g.getService(ScooterBLEConstants.SERVICE_UUID) ?: return
            writeCharacteristic = service.getCharacteristic(ScooterBLEConstants.WRITE_CHARACTERISTIC_UUID)
            val notifyChar = service.getCharacteristic(ScooterBLEConstants.NOTIFY_CHARACTERISTIC_UUID)
            notifyChar?.let {
                g.setCharacteristicNotification(it, true)
                val descriptor = it.getDescriptor(ScooterBLEConstants.CLIENT_CHARACTERISTIC_CONFIG_UUID)
                descriptor?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                descriptor?.let { d -> g.writeDescriptor(d) }
            }
            if (writeCharacteristic != null) {
                requestFirmwareVersion()
                startPolling()
            }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val data = characteristic.value ?: return
            val parsed = NinebotProtocol.parse(data) ?: return
            handleParsedPacket(parsed)
        }
    }

    private fun handleParsedPacket(packet: NinebotProtocol.ParsedPacket) {
        val command = NinebotProtocol.Command.fromValue(packet.command) ?: return
        val payload = packet.payload

        state.value = when (command) {
            NinebotProtocol.Command.READ_BATTERY -> {
                if (payload.size >= 2) {
                    val pct = payload[0].toInt() and 0xFF
                    val raw = (payload[0].toInt() and 0xFF) or ((payload[1].toInt() and 0xFF) shl 8)
                    state.value.copy(batteryPercent = pct, batteryVoltage = raw / 100.0)
                } else state.value
            }
            NinebotProtocol.Command.READ_SPEED -> {
                if (payload.size >= 2) {
                    val raw = (payload[0].toInt() and 0xFF) or ((payload[1].toInt() and 0xFF) shl 8)
                    state.value.copy(currentSpeedKmh = raw / 100.0)
                } else state.value
            }
            NinebotProtocol.Command.READ_MILEAGE -> {
                if (payload.size >= 4) {
                    val raw = (payload[0].toLong() and 0xFF) or
                            ((payload[1].toLong() and 0xFF) shl 8) or
                            ((payload[2].toLong() and 0xFF) shl 16) or
                            ((payload[3].toLong() and 0xFF) shl 24)
                    state.value.copy(totalDistanceKm = raw / 1000.0)
                } else state.value
            }
            NinebotProtocol.Command.READ_FIRMWARE -> {
                val hex = payload.joinToString("") { "%02X".format(it) }
                state.value.copy(firmwareVersion = hex)
            }
            NinebotProtocol.Command.READ_ERROR_CODE -> {
                if (payload.isNotEmpty()) state.value.copy(errorCode = payload[0].toInt() and 0xFF)
                else state.value
            }
            else -> state.value
        }
    }
}
