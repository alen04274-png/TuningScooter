package com.scootertuning.app.bluetooth

import java.util.UUID

/**
 * Implementiert das öffentlich dokumentierte Ninebot/Xiaomi-BLE-Paketformat.
 * Quelle für Protokoll-Grundlagen: Community-Reverse-Engineering (z.B. "Scooter
 * Hacking Utility"-Projekt, diverse GitHub-Repos zu "ninebot-ble-protocol").
 *
 * WICHTIG: Die exakten Payload-Bytes für Freischalt-Kommandos unterscheiden sich
 * je nach Modell (Mi/Pro/Pro2/Max/Essential) und Firmware-Version. Die Konstanten
 * unten sind Platzhalter mit den bekanntesten Werten aus der Community – bevor du
 * live sendest, gegen eine aktuelle Protokoll-Referenz für dein exaktes Modell
 * prüfen (Firmware ändert Offsets gelegentlich).
 */
object NinebotProtocol {

    val HEADER = byteArrayOf(0x5A, 0xA5.toByte())

    enum class Source(val value: Byte) {
        APP(0x21),
        ESC(0x20),
        BLE(0x3D)
    }

    enum class Command(val value: Byte) {
        READ_BATTERY(0x31),
        READ_SPEED(0x32),
        READ_MILEAGE(0x3B),
        READ_MODE(0x70),
        WRITE_MODE(0x71),
        READ_FIRMWARE(0x1A),
        READ_ERROR_CODE(0x3E),
        // Freischalt-Sequenz: mehrstufiger Schreib-Vorgang auf ein
        // herstellerspezifisches Register. Muss modellspezifisch verifiziert werden.
        WRITE_SPEED_LIMIT(0xB0.toByte());

        companion object {
            fun fromValue(v: Byte): Command? = entries.firstOrNull { it.value == v }
        }
    }

    /** Baut ein Ninebot-BLE-Paket: Header, Länge, Adressen, Kommando, Payload, Checksumme */
    fun buildPacket(command: Command, payload: ByteArray = ByteArray(0)): ByteArray {
        val body = mutableListOf<Byte>()
        body.add(payload.size.toByte())
        body.add(Source.APP.value)
        body.add(Source.ESC.value)
        body.add(command.value)
        body.addAll(payload.toList())

        val checksum = computeChecksum(body)

        val packet = mutableListOf<Byte>()
        packet.addAll(HEADER.toList())
        packet.addAll(body)
        packet.add((checksum and 0xFF).toByte())
        packet.add(((checksum shr 8) and 0xFF).toByte())

        return packet.toByteArray()
    }

    private fun computeChecksum(body: List<Byte>): Int {
        var sum = 0
        for (b in body) {
            sum += (b.toInt() and 0xFF)
        }
        sum = sum and 0xFFFF
        return 0xFFFF - sum
    }

    data class ParsedPacket(val command: Byte, val payload: ByteArray)

    fun parse(data: ByteArray): ParsedPacket? {
        if (data.size < 6) return null
        if (data[0] != HEADER[0] || data[1] != HEADER[1]) return null
        val length = data[2].toInt() and 0xFF
        if (data.size < 6 + length) return null
        val command = data[5]
        val payloadLen = maxOf(0, length - 2)
        val payload = data.copyOfRange(6, 6 + payloadLen)
        return ParsedPacket(command, payload)
    }
}

/**
 * GATT UUIDs, wie sie bei Ninebot/Xiaomi Scootern üblich verbaut sind.
 * Je nach Modell können sich UUIDs unterscheiden – ggf. per BLE-Scanner-App
 * (z.B. "nRF Connect") am eigenen Gerät verifizieren.
 */
object ScooterBLEConstants {
    val SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    val WRITE_CHARACTERISTIC_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
    val NOTIFY_CHARACTERISTIC_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")
    val CLIENT_CHARACTERISTIC_CONFIG_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
}
