package com.scootertuning.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.scootertuning.app.bluetooth.BleManager

@Composable
fun RootScreen(bleManager: BleManager) {
    val state by bleManager.state

    if (!state.isConnected) {
        ScanScreen(bleManager = bleManager)
        return
    }

    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Speed, contentDescription = null) },
                    label = { Text("Dashboard") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Bolt, contentDescription = null) },
                    label = { Text("Fahrmodus") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Tuning") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).let { it }) {
            when (selectedTab) {
                0 -> DashboardScreen(bleManager = bleManager)
                1 -> RideModeScreen(bleManager = bleManager)
                2 -> SettingsScreen(bleManager = bleManager)
            }
        }
    }
}
