package com.scootertuning.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scootertuning.app.bluetooth.BleManager

@Composable
fun SettingsScreen(bleManager: BleManager) {
    val state by bleManager.state
    var sliderValue by remember { mutableStateOf(20f) }
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Surface(color = Color(0xFFFFF3E0), shape = MaterialTheme.shapes.medium) {
            Row(modifier = Modifier.padding(12.dp)) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF57C00))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Nur auf Privatgelände ohne öffentlichen Verkehr verwenden. Auf öffentlichen Straßen ist ein entdrosselter Scooter nicht zulässig.",
                    fontSize = 12.sp,
                    color = Color(0xFFF57C00)
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("Geschwindigkeitslimit", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text("%.0f km/h".format(sliderValue), fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Slider(
            value = sliderValue,
            onValueChange = { sliderValue = it },
            valueRange = 5f..45f,
            steps = 39
        )
        Text("Werkslimit: 20 km/h", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { showDialog = true },
            enabled = state.isConnected,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Limit übernehmen")
        }

        Spacer(Modifier.height(32.dp))
        Text("Geräteinfo", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        InfoRow("Firmware", state.firmwareVersion)
        InfoRow("Fehlercode", state.errorCode.toString())
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Geschwindigkeitslimit wirklich ändern?") },
            text = { Text("Nur zur Verwendung auf eigenem Privatgelände.") },
            confirmButton = {
                TextButton(onClick = {
                    bleManager.setSpeedLimit(sliderValue.toDouble())
                    showDialog = false
                }) { Text("Bestätigen") }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Abbrechen") }
            }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}
